cmake_minimum_required(VERSION 3.25...4.2)
project(FakeGTest VERSION 1.0 LANGUAGES CXX)

add_library(fake_gtest INTERFACE)
target_include_directories(fake_gtest INTERFACE ${CMAKE_CURRENT_SOURCE_DIR}/include)
target_compile_definitions(fake_gtest INTERFACE FAKE_GTEST=1)

add_library(GTest::gtest_main ALIAS fake_gtest)
