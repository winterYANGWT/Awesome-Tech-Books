cmake_minimum_required(VERSION 3.25...4.2)
project(Tiny VERSION 1.0 LANGUAGES CXX)

add_library(tiny STATIC tiny.cpp)
target_include_directories(tiny PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
